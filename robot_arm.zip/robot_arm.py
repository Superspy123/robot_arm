import cv2
import numpy as np
import mysql.connector
from mysql.connector import Error
import time

# Function to connect to MySQL database
def connect_to_mysql():
    try:
        connection = mysql.connector.connect(host='localhost',
                                             database='db_robot_arm',
                                             user='root',
                                             password='spyam123')
        if connection.is_connected():
            print("Connected to MySQL database")
            return connection
    except Error as e:
        print("Error while connecting to MySQL", e)
        return None

# Function to update the control table
def update_control_table(connection, status):
    try:
        cursor = connection.cursor()
        query = "UPDATE tb_control SET log_datetime = NOW(), log_data = %s WHERE log_id = 1"
        cursor.execute(query, (status,))
        connection.commit()
        print("Data updated successfully")
    except Error as e:
        print("Error while updating data in tb_control", e)

# Connect to the webcam
cap = cv2.VideoCapture(0)

# Connect to MySQL database
connection = connect_to_mysql()

# Define the scale (example: 0.1 cm per pixel if 10 cm spans 100 pixels)
scale_cm_per_pixel = 0.1

# Set the delay time in seconds
update_delay = 10  # 10 seconds delay
last_update_time = None

while True:
    # Capture frame from webcam
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    # Convert frame to HSV
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    
    # Define color ranges for red and green
    lower_red = np.array([0, 100, 100])
    upper_red = np.array([10, 255, 255])
    
    lower_green = np.array([35, 100, 100])
    upper_green = np.array([85, 255, 255])
    
    # Create masks for red and green
    mask_red = cv2.inRange(hsv, lower_red, upper_red)
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    
    # Detect circles for red tomatoes
    circles_red = cv2.HoughCircles(mask_red, cv2.HOUGH_GRADIENT, dp=1.2, minDist=50, param1=50, param2=30, minRadius=20, maxRadius=100)
    
    # Detect circles for green tomatoes
    circles_green = cv2.HoughCircles(mask_green, cv2.HOUGH_GRADIENT, dp=1.2, minDist=50, param1=50, param2=30, minRadius=20, maxRadius=100)
    
    # Process red circles
    if circles_red is not None:
        circles_red = np.round(circles_red[0, :]).astype("int")
        for (x, y, r) in circles_red:
            area = np.pi * (r ** 2)
            if area < 1000:
                continue
            radius_cm = r * scale_cm_per_pixel  # Convert radius to cm
            cv2.circle(frame, (x, y), r, (0, 0, 255), 3)
            cv2.putText(frame, f"Red Tomato - R: {radius_cm:.2f} cm", (x - 25, y - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 0), 1)
    
    # Process green circles
    if circles_green is not None:
        circles_green = np.round(circles_green[0, :]).astype("int")
        for (x, y, r) in circles_green:
            area = np.pi * (r ** 2)
            if area < 1000:
                continue
            radius_cm = r * scale_cm_per_pixel  # Convert radius to cm
            cv2.circle(frame, (x, y), r, (0, 255, 0), 3)
            cv2.putText(frame, f"Green Tomato - R: {radius_cm:.2f} cm", (x - 25, y - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 0), 1)
    
    # Show result
    cv2.imshow('Frame', frame)
    cv2.imshow('Mask Red', mask_red)
    cv2.imshow('Mask Green', mask_green)
    
    # Update the control table based on the conditions
    current_time = time.time()
    red_present = circles_red is not None
    green_present = circles_green is not None

    if red_present or green_present:
        if last_update_time is None or (current_time - last_update_time >= update_delay):
            if red_present:
                print("Red tomato detected")
                update_control_table(connection, 1)  # Update to 1 when red tomato is detected
            elif green_present:
                print("Green tomato detected")
                update_control_table(connection, 2)  # Update to 2 when green tomato is detected
            last_update_time=current_time
    else:
        if last_update_time is None or (current_time - last_update_time >= update_delay):
            print("No tomato detected")
            update_control_table(connection, 0)  # Update to 0 when no tomato is detected
            last_update_time = current_time
            
        
    
    # Break the loop on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close windows
cap.release()
cv2.destroyAllWindows()
